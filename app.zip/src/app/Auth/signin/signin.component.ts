import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';

import { SigninService } from './../../Services/signin.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  signinForm: FormGroup;
  submitted = false;
  form_error: Boolean;
  stbtn = false;
  
  constructor(
    private signinservice: SigninService,
    private router: Router,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit(): void {
    if(this.signinservice.isLoggedIn()){
      const redirect = this.signinservice.redirectUrl ? this.signinservice.redirectUrl : '/firststep';
      this.router.navigate([redirect]);
    }

    this.signinForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(4)]]
    });
  }

  get f() { return this.signinForm.controls; }

  signin(): void {
    this.submitted = true;
    this.stbtn = true;

    if (this.signinForm.invalid) {
      this.stbtn = false;
      return;
    }

    this.signinservice.signin(this.signinForm.value).subscribe((data)=>{
      if(data == false){
        this.form_error = true;
        this.stbtn = false;
      }else{
        this.stbtn = false;
        this.router.navigate(['./firststep']);
      }
    });
  }
}
