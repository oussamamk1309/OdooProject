import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';

import { ArticlesService } from './../../Services/articles.service';

@Component({
  selector: 'app-add-article',
  templateUrl: './add-article.component.html',
  styleUrls: ['./add-article.component.css']
})
export class AddArticleComponent implements OnInit {

  addForm: FormGroup;
  submitted = false;
  form_error: Boolean;
  stbtn = false;

  constructor(
    private saleordersservice: ArticlesService,
    private router: Router,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit(): void {
    this.addForm = this.formBuilder.group({
      name: ['', Validators.required],
      code: ['', Validators.required],
      price: ['', Validators.required]
    });
  }
  get f() { return this.addForm.controls; }

  addArticle(): void{
    this.submitted = true;
    this.stbtn = true;

    if (this.addForm.invalid) {
      this.stbtn = false;
      return;
    }

    this.saleordersservice.addArticle(this.addForm.value).subscribe((data)=>{
      if((data.faultCode)||(data == false)){
        this.form_error = true;
        this.stbtn = false;
      }else{
        this.stbtn = false;
        this.router.navigate(['./articles']);
      }
    });

  }

  

}
