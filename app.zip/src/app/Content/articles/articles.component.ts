import { Component, OnInit } from '@angular/core';

import { ArticlesService } from './../../Services/articles.service';

@Component({
  selector: 'app-articles',
  templateUrl: './articles.component.html',
  styleUrls: ['./articles.component.css']
})
export class ArticlesComponent implements OnInit {

  articles: Array<any>;
  
  constructor( private saleordersservice: ArticlesService ) {
    this.articles = new Array<any>();
  }

  ngOnInit(): void {
    var div = document.getElementById('load'); 
    this.saleordersservice.getArticles().subscribe((data)=>{
      div.remove();
      this.articles = data;
    });
  }
}
