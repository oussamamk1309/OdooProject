import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { JQueryStyleEventEmitter } from 'rxjs/internal/observable/fromEvent';

import { ArticlesService } from './../../Services/articles.service';

declare var $:JQueryStyleEventEmitter;

@Component({
  selector: 'app-details-article',
  templateUrl: './details-article.component.html',
  styleUrls: ['./details-article.component.css']
})
export class DetailsArticleComponent implements OnInit {
  
  article: Array<any>;
  articleId = this.activatedRoute.snapshot.params.articleId;

  constructor(
    private activatedRoute: ActivatedRoute,
    private articleservice: ArticlesService 
  ) {
    this.article = null;
  }

  ngOnInit(): void { 
    this.articleservice.getDetailsArticle(this.articleId).subscribe((data)=>{
      $("#load").remove();
      this.article = data[0];
    });
  }
}
