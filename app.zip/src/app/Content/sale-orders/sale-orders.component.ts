import { Component, OnInit } from '@angular/core';
import { SaleOrdersService } from './../../Services/sale-orders.service';

@Component({
  selector: 'app-sale-orders',
  templateUrl: './sale-orders.component.html',
  styleUrls: ['./sale-orders.component.css']
})
export class SaleOrdersComponent implements OnInit {

  orders: Array<any>;

  constructor(private saleordersservice: SaleOrdersService) {
    this.orders = new Array<any>();
  }

  ngOnInit(): void {
    var div = document.getElementById('load'); 
    this.saleordersservice.getUserSaleOrders().subscribe((data)=>{
      div.remove();
      this.orders = data;
    });
  }

}
