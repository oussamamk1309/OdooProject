import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ArticlesService {

  constructor(private http: HttpClient) { }

  getArticles(): Observable<any>{
    const url = "http://127.0.0.1:8080/php/getArticles.php";
    return this.http.get(url, {responseType: 'json'});
  }

  addArticle(formData): Observable<any>{
    let res;
    var data = new FormData();
    Object.keys(formData).forEach((key)=>{data.append(key, formData[key])});
    const url = "http://127.0.0.1:8080/php/addArticle.php";
    res = this.http.post(url, data);
    return res;
  }

  getDetailsArticle(id): Observable<any>{
    const url = "http://127.0.0.1:8080/php/getDetailsArticle.php?id="+id;
    return this.http.get(url, {responseType: 'json'});
  }
}
