import { EventEmitter, Injectable, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SigninService {
  redirectUrl: string;
  baseUrl:string = "http://localhost:8080/php";
  @Output() getLoggedInName: EventEmitter<any> = new EventEmitter();

  constructor(private http: HttpClient) { }

  /*verifySession(): Observable<any>{
    const url = "http://127.0.0.1:8080/php/verifySession.php";
    return this.http.get(url, {responseType: 'json'});
  }*/

  signin(formData): Observable<any>{
    let res;
    var data = new FormData();
    Object.keys(formData).forEach((key)=>{data.append(key, formData[key])});
    const url = this.baseUrl+"/signin.php";
    res = this.http.post(url, data);
    if(res != false){
      this.setToken(res);
      this.getLoggedInName.emit(true);
    }
    return res;
  }

  //token
  setToken(token: string) {
    localStorage.setItem('token', token);
  }
  getToken() {
    return localStorage.getItem('token');
  }
  deleteToken() {
    localStorage.removeItem('token');
  }
  isLoggedIn() {
    const usertoken = this.getToken();
    if (usertoken != null) {
      return true
    }
    return false;
  }
  
}
