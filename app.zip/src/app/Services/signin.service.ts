import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SigninService {

  constructor(private http: HttpClient) { }

  /*verifySession(): Observable<any>{
    const url = "http://127.0.0.1:8080/php/verifySession.php";
    return this.http.get(url, {responseType: 'json'});
  }*/

  signin(formData): Observable<any>{
    let res;
    var data = new FormData();
    Object.keys(formData).forEach((key)=>{data.append(key, formData[key])});
    const url = "http://127.0.0.1:8080/php/signin.php";
    res = this.http.post(url, data);
    return res;
  }
  
}
