import { Component, OnInit } from '@angular/core';

import { SigninService } from '../Services/signin.service';

@Component({
  selector: 'app-top-bar',
  templateUrl: './top-bar.component.html',
  styleUrls: ['./top-bar.component.css']
})
export class TopBarComponent implements OnInit {

  constructor(private signinservice: SigninService) { }

  ngOnInit(): void {
  }


  logout(){
    this.signinservice.deleteToken();
    window.location.href = window.location.href;
  }
}
