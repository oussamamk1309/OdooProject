import { Component } from '@angular/core';
import {Location, LocationStrategy, PathLocationStrategy} from '@angular/common';
import { Router,NavigationStart, Event as NavigationEvent } from '@angular/router';

import { SigninService } from './Services/signin.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  event$
  showBar= true;
  location: Location;
  title = 'app';

  constructor(location: Location,private router: Router) {
    this.location = location;
    this.event$ = this.router.events.subscribe((event: NavigationEvent) => {
      if(event instanceof NavigationStart) {
        if(event.url == "/signin"){
          this.showBar = false;
        }else{
          this.showBar = true;
        }
      }
    });
  }
}
