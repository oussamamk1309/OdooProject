import { Component } from '@angular/core';
import { Location } from "@angular/common";
import { Router } from "@angular/router";

import { SigninService } from './Services/signin.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  route: string;
  login:boolean;
  title = 'app';

  constructor(private signinservice: SigninService, location: Location, router: Router) {
    router.events.subscribe((val) => {
      if(this.signinservice.isLoggedIn()){
        this.login = true;
      }else{
        this.login = false;
      }
    });

  }
}
