import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SigninComponent } from './Auth/signin/signin.component';
import { FrontComponent } from './front/front.component';
import { ArticlesComponent } from './Content/articles/articles.component';
import { SaleOrdersComponent } from './Content/sale-orders/sale-orders.component';
import { TopBarComponent } from './top-bar/top-bar.component';

import { SaleOrdersService } from './Services/sale-orders.service';
import { ArticlesService } from './Services/articles.service';
import { AddArticleComponent } from './Content/add-article/add-article.component';
import { DetailsArticleComponent } from './Content/details-article/details-article.component';

@NgModule({
  declarations: [
    AppComponent,
    SigninComponent,
    FrontComponent,
    ArticlesComponent,
    SaleOrdersComponent,
    TopBarComponent,
    AddArticleComponent,
    DetailsArticleComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule 
  ],
  providers: [
    SaleOrdersService,
    ArticlesService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
