import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SigninComponent } from './Auth/signin/signin.component';
import { FrontComponent } from './front/front.component';
import { SaleOrdersComponent } from './Content/sale-orders/sale-orders.component';
import { ArticlesComponent } from './Content/articles/articles.component';
import { AddArticleComponent } from './Content/add-article/add-article.component';

const routes: Routes = [
  { path: '', redirectTo: '/firststep', pathMatch: 'full'},
  { path: 'signin', component: SigninComponent},
  { path: 'firststep', component:  FrontComponent},
  { path: 'sale-orders', component:  SaleOrdersComponent},
  { path: 'articles', component:  ArticlesComponent},
  { path: 'articles/create', component:  AddArticleComponent},
  { path: '**', redirectTo: '/firststep', pathMatch: 'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
