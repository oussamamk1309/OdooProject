import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SigninComponent } from './Auth/signin/signin.component';
import { FrontComponent } from './front/front.component';
import { SaleOrdersComponent } from './Content/sale-orders/sale-orders.component';
import { ArticlesComponent } from './Content/articles/articles.component';
import { AddArticleComponent } from './Content/add-article/add-article.component';
import { DetailsArticleComponent } from './Content/details-article/details-article.component';

import { AuthguardGuard } from './authguard.guard';

const routes: Routes = [
  { path: '', redirectTo: '/signin', pathMatch: 'full'},
  { path: 'signin', component: SigninComponent},
  { path: 'firststep', component:  FrontComponent, canActivate: [AuthguardGuard]},
  { path: 'sale-orders', component:  SaleOrdersComponent, canActivate: [AuthguardGuard]},
  { path: 'articles', component:  ArticlesComponent, canActivate: [AuthguardGuard]},
  { path: 'articles/create', component:  AddArticleComponent, canActivate: [AuthguardGuard]},
  { path: 'articles/:articleId', component:  DetailsArticleComponent, canActivate: [AuthguardGuard]},
  { path: '**', redirectTo: '/firststep', pathMatch: 'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
