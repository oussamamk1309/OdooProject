<?php
    phpinfo();
