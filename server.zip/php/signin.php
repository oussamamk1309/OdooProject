<?php 
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Allow-Credentials: true");
    header("Content-Type: application/json; charset=UTF-8");
    
    $url = "http://localhost:8069";
    $db = "projetInetg";

    require_once('./config/ripcord.php');
    $common = ripcord::client("$url/xmlrpc/2/common");
    $common->version();

    if(isset($_POST['username'])){
        $username = $_POST['username'];
        $password = $_POST['password'];

        $uid = $common->authenticate($db, $username, $password, array());
        
        echo json_encode($uid);
    }
    
    /*$uid = $common->authenticate($db, $username, $password, array());

    if($uid != false){
        $_SESSION['uid'] = $uid;
        $_SESSION['username'] = $username;
        $_SESSION['password'] = $password;
    }
    
    echo json_encode($uid);*/

?>
