<?php 

    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Allow-Credentials: true");
    header("Content-Type: application/json; charset=UTF-8");
    
    $url = "http://localhost:8069";
    $db = "projetInetg";
    $username = "oussmk09@gmail.com";
    $password = "admin";

    require_once('./config/ripcord.php');
    $common = ripcord::client("$url/xmlrpc/2/common");
    $common->version();
    
    $uid = $common->authenticate($db, $username, $password, array());

    $models = ripcord::client("$url/xmlrpc/2/object");

    if(isset($_POST['name'])){
        $name = $_POST['name'];
        $list_price = $_POST['price'];
        $default_code = $_POST['code'];
        $id = $models->execute_kw($db, $uid, $password,
                'product.template', 'create',
                array(array([
                    "name"=>$name,
                    "list_price"=>$list_price,
                    "default_code"=>$default_code
                ]))
            );
        echo json_encode($id);
    }


?>
