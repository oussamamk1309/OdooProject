<?php 

    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Allow-Credentials: true");
    header("Content-Type: application/json; charset=UTF-8");
    
    $url = "http://localhost:8069";
    $db = "projetInetg";
    $username = "oussmk09@gmail.com";
    $password = "admin";

    require_once('./config/ripcord.php');
    $common = ripcord::client("$url/xmlrpc/2/common");
    $common->version();
    
    $uid = $common->authenticate($db, $username, $password, array());

    $models = ripcord::client("$url/xmlrpc/2/object");

    if(isset($_POST['id'])){
        $id = $_POST['id'];
        $id = $models->execute_kw($db, $uid, $password,
                'product.template', 'unlink',
                array(array($id))
            );
        $result = $models->execute_kw($db, $uid, $password,
                'product.template', 'search',
                array(array(array('id', '=', $id)))
            );
        echo json_encode($id);
    }


?>
