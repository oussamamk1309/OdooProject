<?php 
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: access");
    header("Access-Control-Allow-Methods: *");
    header("Access-Control-Allow-Credentials: true");
    header("Content-Type: application/json; charset=UTF-8");
    
    $url = "http://localhost:8069";
    $db = "projetInetg";
    $username = "oussmk09@gmail.com";
    $password = "admin";

    require_once('./config/ripcord.php');
    $common = ripcord::client("$url/xmlrpc/2/common");
    $common->version();
    
    $uid = $common->authenticate($db, $username, $password, array());

    $models = ripcord::client("$url/xmlrpc/2/object");

    $ids = $models->execute_kw($db, $uid, $password,
            'sale.order', 'search',
            array(array(array('user_id','=',$uid)))
        );
    $records = $models->execute_kw($db, $uid, $password,
            'sale.order', 'read', array($ids),
            array('fields'=>array('id', 'name', 'date_order', 'partner_id', 'amount_total', 'state'))
        );
    echo json_encode($records);

?>
